export const DEFAULT_BACKEND_URL = "http://127.0.0.1:8787";
export const REQUEST_TIMEOUT_MS = 60_000;
export const CHARACTER_LIMIT = 25_000;
export const SERVER_NAME = "zoey-mcp-server";
export const SERVER_VERSION = "1.0.0";
