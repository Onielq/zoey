export interface HealthResponse {
  ok: boolean;
  backend: string;
  oauth: { googleConfigured: boolean };
  providers: Record<string, { configured: boolean; voiceId: string }>;
  google: { connected: boolean; email?: string; services?: string[] };
}

export interface ChatResponse {
  ok: boolean;
  answer: string;
  agent: string;
  route: string;
  modelProviders: { openai: boolean; gemini: boolean };
}

export interface ProviderTestResponse {
  ok: boolean;
  detail: string;
}

export interface CalendarEvent {
  id: string;
  summary: string;
  start?: { dateTime?: string; date?: string; timeZone?: string };
  end?: { dateTime?: string; date?: string; timeZone?: string };
  source: string;
}

export interface CalendarTodayResponse {
  ok: boolean;
  events: CalendarEvent[];
}

export interface CreatedEventResponse {
  ok: boolean;
  event: {
    id?: string;
    summary?: string;
    htmlLink?: string;
    start?: { dateTime?: string; timeZone?: string };
    end?: { dateTime?: string; timeZone?: string };
  };
}
