import { z } from "zod";
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { ZoeyClient, explainError } from "../services/zoey-client.js";
import type { ChatResponse, ProviderTestResponse } from "../types.js";
import { ok, fail } from "./shared.js";

export function registerChatTools(server: McpServer, client: ZoeyClient) {
  server.registerTool(
    "zoey_chat",
    {
      title: "Chat with Zoey",
      description: `Send one message to Zoey, the backend's orchestrator. The backend picks a specialist route (Scheduling, Real Estate, Finance, Research, Coding, Communication, or General), tries OpenAI first, then Google Gemini.

This adds the turn to Zoey's short memory on the session (last 8 turns are sent back as context). It does not run tools or write to the calendar. To create events use zoey_calendar_create_event.

Args:
  - message (string): what to ask Zoey, 1-4000 chars

Returns (structuredContent):
  { "answer": string, "agent": string, "route": string, "providers": { "openai": boolean, "gemini": boolean } }

Errors:
  - "No connected model provider could answer" -> no OpenAI or Gemini key on this session. Call zoey_get_status.`,
      inputSchema: z
        .object({
          message: z.string().trim().min(1, "Message can't be empty").max(4000, "Message must be 4000 characters or fewer"),
        })
        .strict(),
      outputSchema: {
        answer: z.string(),
        agent: z.string(),
        route: z.string(),
        providers: z.object({ openai: z.boolean(), gemini: z.boolean() }),
      },
      annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true },
    },
    async ({ message }) => {
      try {
        const r = await client.request<ChatResponse>("POST", "/api/zoey/chat", { message, voice: false });
        const out = {
          answer: r.answer,
          agent: r.agent,
          route: r.route,
          providers: { openai: Boolean(r.modelProviders?.openai), gemini: Boolean(r.modelProviders?.gemini) },
        };
        return ok(`${r.answer}\n\n— ${r.route}`, out);
      } catch (e) {
        return fail(explainError(e, client));
      }
    }
  );

  server.registerTool(
    "zoey_test_provider",
    {
      title: "Test a saved provider key",
      description: `Check that a provider key already saved on the session still works. The backend calls that provider's "list models" endpoint.

You can't pass a key here on purpose. Keys should be saved in the Zoey UI, not typed into a chat where they'd be logged.

Args:
  - provider (string): the exact name shown in zoey_get_status, e.g. "OpenAI", "Google Gemini", "ElevenLabs", "Anthropic / Claude", "DeepSeek", "Groq", "OpenRouter"

Returns (structuredContent): { "provider": string, "detail": string }

Errors:
  - "<provider> API key is missing" -> nothing saved under that exact name. Call zoey_get_status.`,
      inputSchema: z
        .object({ provider: z.string().trim().min(1, "Provider name is required").max(60) })
        .strict(),
      outputSchema: { provider: z.string(), detail: z.string() },
      annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: true },
    },
    async ({ provider }) => {
      try {
        const r = await client.request<ProviderTestResponse>("POST", "/api/providers/test", { provider });
        return ok(`${provider}: ${r.detail}`, { provider, detail: r.detail });
      } catch (e) {
        return fail(explainError(e, client));
      }
    }
  );
}
