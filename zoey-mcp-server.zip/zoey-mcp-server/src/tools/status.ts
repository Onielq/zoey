import { z } from "zod";
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { ZoeyClient, explainError } from "../services/zoey-client.js";
import type { HealthResponse } from "../types.js";
import { ResponseFormat, responseFormatField, ok, fail } from "./shared.js";

export function registerStatusTools(server: McpServer, client: ZoeyClient) {
  server.registerTool(
    "zoey_get_status",
    {
      title: "Get Zoey backend status",
      description: `Check the Zoey OS backend: which model/voice providers have a saved key, whether Google Calendar is connected, and whether this MCP server shares the browser's session.

Call this first when another zoey_ tool fails with "not connected". It never changes anything and never returns API keys.

Args:
  - response_format ('markdown' | 'json'): default 'markdown'

Returns (structuredContent):
  {
    "backend_ok": boolean,
    "google_oauth_configured": boolean,   // backend has client id + secret
    "google": { "connected": boolean, "email": string, "services": string[] },
    "providers": [ { "name": string, "configured": boolean, "voice_id_set": boolean } ],
    "session": { "hint": string, "shares_browser_session": boolean }
  }

Don't use this to read chat history or skills/workflows. The backend has no endpoints for those.`,
      inputSchema: z.object({ response_format: responseFormatField }).strict(),
      outputSchema: {
        backend_ok: z.boolean(),
        google_oauth_configured: z.boolean(),
        google: z.object({
          connected: z.boolean(),
          email: z.string(),
          services: z.array(z.string()),
        }),
        providers: z.array(
          z.object({ name: z.string(), configured: z.boolean(), voice_id_set: z.boolean() })
        ),
        session: z.object({ hint: z.string(), shares_browser_session: z.boolean() }),
      },
      annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false },
    },
    async ({ response_format }) => {
      try {
        const h = await client.request<HealthResponse>("GET", "/api/health");
        const providers = Object.entries(h.providers || {}).map(([name, v]) => ({
          name,
          configured: Boolean(v.configured),
          voice_id_set: Boolean(v.voiceId),
        }));
        const out = {
          backend_ok: Boolean(h.ok),
          google_oauth_configured: Boolean(h.oauth?.googleConfigured),
          google: {
            connected: Boolean(h.google?.connected),
            email: h.google?.email || "",
            services: h.google?.services || [],
          },
          providers,
          session: { hint: client.sessionHint, shares_browser_session: client.sharesBrowserSession },
        };

        if (response_format === ResponseFormat.JSON) return ok(JSON.stringify(out, null, 2), out);

        const lines = [
          "# Zoey backend",
          `- Backend: ${out.backend_ok ? "up" : "down"} (${client.baseUrl})`,
          `- Google OAuth set up on backend: ${out.google_oauth_configured ? "yes" : "no"}`,
          `- Google Calendar: ${out.google.connected ? `connected (${out.google.email || "no email"})` : "not connected"}`,
          `- Session: ${out.session.hint} · ${out.session.shares_browser_session ? "shared with the browser" : "own session (may be empty)"}`,
          "",
          "## Providers",
        ];
        if (!providers.length) lines.push("None saved on this session.");
        for (const p of providers) {
          lines.push(`- ${p.name}: ${p.configured ? "key saved" : "no key"}${p.voice_id_set ? " · voice id set" : ""}`);
        }
        if (!providers.length && !out.session.shares_browser_session) {
          lines.push(
            "",
            "Tip: set ZOEY_SESSION_ID to the browser's session id (localStorage.getItem('zoeyBackendSession')) to use the keys you already saved in the UI."
          );
        }
        return ok(lines.join("\n"), out);
      } catch (e) {
        return fail(explainError(e, client));
      }
    }
  );
}
