import { z } from "zod";
import { CHARACTER_LIMIT } from "../constants.js";

export enum ResponseFormat {
  MARKDOWN = "markdown",
  JSON = "json",
}

export const responseFormatField = z
  .nativeEnum(ResponseFormat)
  .default(ResponseFormat.MARKDOWN)
  .describe("'markdown' for readable text, 'json' for structured data");

export function truncate(text: string): string {
  if (text.length <= CHARACTER_LIMIT) return text;
  return text.slice(0, CHARACTER_LIMIT) + "\n\n[Truncated: response exceeded the size limit.]";
}

export function ok<T extends Record<string, unknown>>(text: string, structured: T) {
  return { content: [{ type: "text" as const, text: truncate(text) }], structuredContent: structured };
}

export function fail(text: string) {
  return { isError: true, content: [{ type: "text" as const, text }] };
}
