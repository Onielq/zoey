import { z } from "zod";
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { ZoeyClient, explainError } from "../services/zoey-client.js";
import type { CalendarTodayResponse, CreatedEventResponse } from "../types.js";
import { ResponseFormat, responseFormatField, ok, fail } from "./shared.js";

const HHMM = /^([01]\d|2[0-3]):[0-5]\d$/;

function when(t?: { dateTime?: string; date?: string }): string {
  if (!t) return "?";
  if (t.date && !t.dateTime) return `${t.date} (all day)`;
  return t.dateTime || "?";
}

export function registerCalendarTools(server: McpServer, client: ZoeyClient) {
  server.registerTool(
    "zoey_calendar_today",
    {
      title: "List today's Google Calendar events",
      description: `List today's events (midnight to 23:59 server time) from the primary Google Calendar connected to the Zoey backend, ordered by start time. Max 50 events.

Args:
  - response_format ('markdown' | 'json'): default 'markdown'

Returns (structuredContent):
  { "count": number, "events": [ { "id": string, "summary": string, "start": string, "end": string } ] }

Errors:
  - "Google Calendar is not connected" -> sign in with Google in the Zoey UI, then make sure this server uses the same session (zoey_get_status).`,
      inputSchema: z.object({ response_format: responseFormatField }).strict(),
      outputSchema: {
        count: z.number(),
        events: z.array(z.object({ id: z.string(), summary: z.string(), start: z.string(), end: z.string() })),
      },
      annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: true },
    },
    async ({ response_format }) => {
      try {
        const r = await client.request<CalendarTodayResponse>("GET", "/api/calendar/today");
        const events = (r.events || []).map((e) => ({
          id: e.id,
          summary: e.summary,
          start: when(e.start),
          end: when(e.end),
        }));
        const out = { count: events.length, events };
        if (response_format === ResponseFormat.JSON) return ok(JSON.stringify(out, null, 2), out);
        if (!events.length) return ok("No events on today's calendar.", out);
        const lines = [`# Today (${events.length} event${events.length === 1 ? "" : "s"})`, ""];
        for (const e of events) lines.push(`- **${e.summary}** · ${e.start} → ${e.end}`);
        return ok(lines.join("\n"), out);
      } catch (e) {
        return fail(explainError(e, client));
      }
    }
  );

  server.registerTool(
    "zoey_calendar_create_event",
    {
      title: "Create a Google Calendar event",
      description: `Create one event on the primary Google Calendar. This writes to a real calendar and each call makes a new event, so don't retry blindly. Check zoey_calendar_today first if unsure.

The backend fixes the time zone to Africa/Kigali (UTC+2). Times you pass are read in that zone, whatever the person's own zone is.

Args:
  - title (string): event title, 1-200 chars
  - date (string): YYYY-MM-DD, e.g. "2026-10-03"
  - start (string): 24-hour HH:MM, e.g. "09:30"
  - end (string): 24-hour HH:MM, later than start (same day only)

Returns (structuredContent):
  { "id": string, "title": string, "start": string, "end": string, "link": string }

Errors:
  - "Google Calendar is not connected" -> see zoey_get_status.`,
      inputSchema: z
        .object({
          title: z.string().trim().min(1, "Title is required").max(200),
          date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use YYYY-MM-DD, e.g. 2026-10-03"),
          start: z.string().regex(HHMM, "Use 24-hour HH:MM, e.g. 09:30"),
          end: z.string().regex(HHMM, "Use 24-hour HH:MM, e.g. 10:00"),
        })
        .strict()
        .refine((v) => v.end > v.start, { message: "end must be later than start (same day)", path: ["end"] })
        .refine((v) => !Number.isNaN(Date.parse(`${v.date}T00:00:00Z`)), { message: "date is not a real date", path: ["date"] }),
      outputSchema: {
        id: z.string(),
        title: z.string(),
        start: z.string(),
        end: z.string(),
        link: z.string(),
      },
      annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true },
    },
    async (args) => {
      try {
        const r = await client.request<CreatedEventResponse>("POST", "/api/calendar/events", {
          provider: "Google Calendar",
          ...args,
        });
        const ev = r.event || {};
        const out = {
          id: ev.id || "",
          title: ev.summary || args.title,
          start: ev.start?.dateTime || `${args.date}T${args.start}:00`,
          end: ev.end?.dateTime || `${args.date}T${args.end}:00`,
          link: ev.htmlLink || "",
        };
        return ok(
          `Created "${out.title}" · ${out.start} → ${out.end} (Africa/Kigali)${out.link ? `\n${out.link}` : ""}`,
          out
        );
      } catch (e) {
        return fail(explainError(e, client));
      }
    }
  );
}
