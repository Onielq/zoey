#!/usr/bin/env node
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { SERVER_NAME, SERVER_VERSION } from "./constants.js";
import { ZoeyClient } from "./services/zoey-client.js";
import { registerStatusTools } from "./tools/status.js";
import { registerChatTools } from "./tools/chat.js";
import { registerCalendarTools } from "./tools/calendar.js";

async function main() {
  const server = new McpServer({ name: SERVER_NAME, version: SERVER_VERSION });
  const client = new ZoeyClient();

  registerStatusTools(server, client);
  registerChatTools(server, client);
  registerCalendarTools(server, client);

  // stdio: stdout belongs to the protocol. Log to stderr only.
  await server.connect(new StdioServerTransport());
  console.error(`${SERVER_NAME} ready · backend ${client.baseUrl}`);
}

main().catch((err) => {
  console.error("Fatal:", err);
  process.exit(1);
});
