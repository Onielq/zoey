import { DEFAULT_BACKEND_URL, REQUEST_TIMEOUT_MS } from "../constants.js";

export class ZoeyApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public details?: unknown
  ) {
    super(message);
    this.name = "ZoeyApiError";
  }
}

/**
 * Thin client for the Zoey OS local backend.
 *
 * The backend keeps provider keys and Google tokens in an in-memory session.
 * A session is picked by the X-Zoey-Session header. If the id is unknown, the
 * backend silently starts a NEW empty session and returns its id. So this client
 * remembers the id the backend returns and flags when it differs from the one
 * we asked for.
 */
export class ZoeyClient {
  readonly baseUrl: string;
  private sessionId: string;
  private requestedSessionId: string;
  sessionReplaced = false;

  constructor() {
    this.baseUrl = (process.env.ZOEY_BACKEND_URL || DEFAULT_BACKEND_URL).replace(/\/+$/, "");
    this.requestedSessionId = (process.env.ZOEY_SESSION_ID || "").trim();
    this.sessionId = this.requestedSessionId;
  }

  /** Last 4 chars only. The full id works like a password for the session. */
  get sessionHint(): string {
    return this.sessionId ? `…${this.sessionId.slice(-4)}` : "none yet";
  }

  get sharesBrowserSession(): boolean {
    return Boolean(this.requestedSessionId) && !this.sessionReplaced;
  }

  async request<T>(method: "GET" | "POST", path: string, body?: unknown): Promise<T> {
    let response: Response;
    try {
      response = await fetch(`${this.baseUrl}${path}`, {
        method,
        headers: {
          Accept: "application/json",
          ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
          ...(this.sessionId ? { "X-Zoey-Session": this.sessionId } : {}),
        },
        body: body !== undefined ? JSON.stringify(body) : undefined,
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      });
    } catch (err) {
      if (err instanceof Error && (err.name === "TimeoutError" || err.name === "AbortError")) {
        throw new ZoeyApiError(
          `The Zoey backend at ${this.baseUrl} did not answer within ${REQUEST_TIMEOUT_MS / 1000}s.`,
          504
        );
      }
      throw new ZoeyApiError(
        `Can't reach the Zoey backend at ${this.baseUrl}. Start it with "node zoey_backend.mjs", or set ZOEY_BACKEND_URL.`,
        0
      );
    }

    const returned = response.headers.get("x-zoey-session");
    if (returned) {
      if (this.requestedSessionId && returned !== this.requestedSessionId) {
        // Backend did not know our id and made a new, empty session.
        this.sessionReplaced = true;
      }
      this.sessionId = returned;
    }

    const text = await response.text();
    let data: any = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      /* non-JSON body */
    }

    if (!response.ok) {
      throw new ZoeyApiError(
        data?.error || `${response.status} ${response.statusText}`,
        response.status,
        data?.details
      );
    }
    return data as T;
  }
}

/** Turn any thrown error into a message that tells the caller what to do next. */
export function explainError(err: unknown, client: ZoeyClient): string {
  if (!(err instanceof ZoeyApiError)) {
    return `Error: ${err instanceof Error ? err.message : String(err)}`;
  }
  const lines = [`Error: ${err.message}`];
  if (Array.isArray(err.details) && err.details.length) {
    lines.push(`Details: ${err.details.join(" | ")}`);
  }
  const msg = err.message.toLowerCase();
  const sessionHelp =
    "The backend keeps keys and Google tokens in memory per session. " +
    (client.sessionReplaced
      ? "The session id in ZOEY_SESSION_ID was not found (the backend may have restarted), so a new empty session was started. Copy a fresh id from the browser: localStorage.getItem('zoeyBackendSession')."
      : "This server is on a session with no saved connections. Set ZOEY_SESSION_ID to the browser's id: localStorage.getItem('zoeyBackendSession').");
  if (msg.includes("not connected") || msg.includes("no connected model provider") || msg.includes("api key is missing")) {
    lines.push(sessionHelp);
    lines.push("Call zoey_get_status to see which providers are connected.");
  } else if (err.status === 501) {
    lines.push("The backend has no adapter for this yet.");
  }
  return lines.join("\n");
}
